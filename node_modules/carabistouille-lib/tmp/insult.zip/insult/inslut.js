var restclient = require('node-restclient');
var Twit = require('twit');
var app = require('express').createServer();

// I deployed to Nodejitsu, which requires an application to respond to HTTP requests
// If you're running locally you don't need this, or express at all.
//app.get('/', function(req, res){
//    res.send('Hello world.');
//});
//app.listen(3000);

// insert your twitter app info here
var T = new Twit({
  consumer_key:         'AG7tBD50fTSX6p5rvcXD3iFwN', 
  consumer_secret:      'iv8qbfAmYQE8DHEhlsT04hXRinnP7CaEZLUZ3ArCP2hfr3J8wt',
  access_token:         '4878139721-mt72Sv2vXrmVrpX9bTTTLVyyx4MG0yQTN4QfiXF',
  access_token_secret:  'oQypl8QutsvMn23kZjZuqNF97U0P5gvEmvQKeQNQmrUvZ'
});

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

String.prototype.replaceAt=function(index, character) {
    return this.substr(0, index) + character + this.substr(index+character.length);
}

function startWithAVoyelle(string)
{
	if (string.charAt(0) == "a" || 
			string.charAt(0) == "e" || 
			string.charAt(0) == "i" || 
			string.charAt(0) == "o" || 
			string.charAt(0) == "u" || 
			string.charAt(0) == "h")
	{
		return true;
	}
	return false;
}

var statement =   "";

var accroches = ["espèce de ", "tu t'es vu avec ta face de ", "rentre chez toi, ", "", "", "", "", "rentre chez ta mère, ", "hé, ", "passe ton chemin, " ]
var accrocheSansArticles = ["t'es qu'", "t'as la gueule d'"]
var noms = ["hippie", "hipster", "communiste", "nazi", "clown", "nerd", "prout", "pirate", "quadrupède", "aztèque", "ivrogne", "macaque", "technocrate", "vampire", "environementaliste"]
var nomsF = ["raclure", "pourriture", "chaussette", "mule", "limace", "huître", "horloge murale", "carie", "chèvre", "pile", "crème pâtissière", "annesse", "niche", "camionnette", "machine à laver", "baignoire", "pastèque", "bossue", "chauve-souris", "flaque", "luge", "gourgandine", "antiquité", "caisse", "pantoufle", "cornemuse", "patate", "végétarienne", "perruche", "farceuse", "boite de conserve", "graine", "brouette", "scélérate", "délinquante", "levure", "gorge", "machine à écrire", "mononucléose", "mamie", "gobeuse de mouches"]
var nomsM = ["canoe", "jambon", "hibou", "caniveau", "gaufrier", "biscuit", "montagnard", "goblin", "mangeur de tarte", "dromadaire", "bâteau à voile", "fakir", "monosourcil", "pneu creuvé", "fond de placard", "poil de nez", "corps au pied", "accordéon", "poney", "sac à douche", "égoutoir", "zèbre", "clairon", "post-it", "robinet", "bossu", "rouleau à pâtisserie", "igloo", "benne à ordure", "chiffon", "poulpe", "fémur", "ravioli", "apache", "athlète", "bandit", "bibelot", "cornichon", "chaufard", "cigare", "diplodocus", "galopin", "hydrocarbure", "tapis", "topinambour", "végétarien", "farceur", "mille-pattes", "chercheur", "convoyeur", "scélérat", "délinquant", "loubard", "orifice", "enzyme", "épouvantail", "lombric", "brouillon", "déserteur", "vendeur de mort", "papy", "gobeur de mouches"]
var adjectifs = ["étrange", "communiste", "de mes deux", "stupide", "ignoble", "aveugle", "immense", "zinzin", "sans fond", "convexe", "en plastique", "de mauvaise famille", "verdâtre", "analphabète", "mégalomane", "ramollie", "interplanétaire", "en chaussette", "bancale", "indéchiffrable", "angoissant", "lubrique", "tolérable", "vulgaire", "minable", "négligeable", "pas pire", "convenable", "cataclysmique", "catastrophique", "boute-en-train", "épouventable", "innommable", "incrédule"]
var adjectifsF = ["puante", "ideuse", "dégénérée", "pas belle", "bruyante", "usagée", "trouée", "dissonante", "pas fraiche", "manquée", "ancienne", "pas terminée", "bossue", "cabossée", "boueuse", "dévergondée", "maquillée", "volante", "hurluberlue", "vénéneuse", "écervelée", "revendicatrice", "absolue", "recyclée", "pas satisfaisante", "disjonctée", "ennuyante", "insuffisante", "insignifiante", "infernale"]
var adjectifsM = ["puant", "ideux", "dégénéré", "pas beau", "bruyant", "usagé", "troué", "dissonant", "pas frais", "manqué", "ancien", "pas terminé", "bossu", "cabossé", "boueux", "niais", "dévergondé", "maquillé", "volant", "hurluberlu", "vénéneux", "écervelé", "revendicateur", "absolu", "recyclé", "pas satisfaisant", "disjoncté", "ennuyante", "insuffisant", "insignifiant", "infernal"]

var allAdjectifs = adjectifs.concat(adjectifsF);
allAdjectifs = allAdjectifs.concat(adjectifsM);

function makeMetaphor() {
  statement = "";

var accroche = accroches[Math.floor(Math.random()*accroches.length)];
var accrocheSansArticle = accrocheSansArticles[Math.floor(Math.random()*accrocheSansArticles.length)];
var nom = noms[Math.floor(Math.floor(Math.random()*noms.length))];
var nomF = nomsF[Math.floor(Math.random()*nomsF.length)];
var nomM = nomsM[Math.floor(Math.random()*nomsM.length)];
var adjectif = adjectifs[Math.floor(Math.random()*adjectifs.length)];
var allAdjectif = allAdjectifs[Math.floor(Math.random()*allAdjectifs.length)];
var adjectifF = adjectifsF[Math.floor(Math.random()*adjectifsF.length)];
var adjectifM = adjectifsM[Math.floor(Math.random()*adjectifsM.length)];

var needApostropheNom = false;
var needApostropheNomF = false;
var needApostropheNomM = false;

if ((accroche.charAt(accroche.length - 2) == "e")
		||
		(accroche.charAt(accroche.length - 2) == "a"))
{
	if (startWithAVoyelle(nom))
	{
		needApostropheNom = true;
	}
	if (startWithAVoyelle(nomF))
	{
		needApostropheNomF = true;
	}
	if (startWithAVoyelle(nomM))
	{
		needApostropheNomM = true;
	}

}

if (Math.floor(Math.random()*6) == 0) {
switch (Math.floor(Math.random()*4))
{
case 0:
	statement = "" + accrocheSansArticle + "un " + nomM + " " + adjectifM;
break;
case 1:
	statement = "" + accrocheSansArticle + "une " + nomF + " " + adjectifF;
break;
case 2:
	statement = "" + accrocheSansArticle + "un " + nom + " " + adjectifM;
break;
case 3:
	statement = "" + accrocheSansArticle + "une " + nom + " " + adjectifF;
break;
}
    }
else
{
switch (Math.floor(Math.random()*3))
{
case 0:
if (needApostropheNom)
{
	accroche = accroche.replaceAt(accroche.length - 2, "'");
	accroche = accroche.slice(0, -1);
}
	 statement = "" + accroche + nom + " " + allAdjectif;
break;
case 1:
if (needApostropheNomM)
{
	accroche = accroche.replaceAt(accroche.length - 2, "'");
	accroche = accroche.slice(0, -1);
}
	 statement = "" + accroche + nomM + " " + adjectifM;
break;
case 2:
if (needApostropheNomF)
{
	accroche = accroche.replaceAt(accroche.length - 2, "'");
	accroche = accroche.slice(0, -1);
}
	 statement = "" + accroche + nomF + " " + adjectifF;
break;
}
}

statement += " !";
statement = capitalizeFirstLetter(statement);
        console.log(statement);
        T.post('statuses/update', { status: statement}, function(err, reply) {
          console.log("error: " + err);
          console.log("reply: " + reply);
        });
}

function favRTs () {
  T.get('statuses/retweets_of_me', {}, function (e,r) {
    for(var i=0;i<r.length;i++) {
      T.post('favorites/create/'+r[i].id_str,{},function(){});
    }
    console.log('harvested some RTs'); 
  });
}

// every 2 minutes, make and tweet a metaphor
// wrapped in a try/catch in case Twitter is unresponsive, don't really care about error
// handling. it just won't tweet.
setInterval(function() {
  try {
    makeMetaphor();
  }
 catch (e) {
    console.log(e);
  }
},1200000);

// every 5 hours, check for people who have RTed a metaphor, and favorite that metaphor
setInterval(function() {
  try {
    favRTs();
  }
 catch (e) {
    console.log(e);
  }
},60000*60*5);

